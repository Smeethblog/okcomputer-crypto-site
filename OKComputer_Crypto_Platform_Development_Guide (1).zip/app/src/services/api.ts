// API Service for CryptoVault Backend
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Helper function for API calls
async function apiCall(
  endpoint: string,
  options: RequestInit = {}
): Promise<any> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const config: RequestInit = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  };

  // Add auth token if available
  const token = localStorage.getItem('token');
  if (token) {
    config.headers = {
      ...config.headers,
      Authorization: `Bearer ${token}`,
    };
  }

  const response = await fetch(url, config);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Something went wrong');
  }

  return data;
}

// Auth API
export const authAPI = {
  register: (userData: { email: string; password: string; firstName: string; lastName: string }) =>
    apiCall('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    }),

  login: (credentials: { email: string; password: string }) =>
    apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),

  getMe: () => apiCall('/auth/me'),

  updateProfile: (data: { firstName?: string; lastName?: string }) =>
    apiCall('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  changePassword: (data: { currentPassword: string; newPassword: string }) =>
    apiCall('/auth/password', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  setup2FA: () => apiCall('/auth/2fa/setup', { method: 'POST' }),
  
  verify2FA: (code: string) =>
    apiCall('/auth/2fa/verify', {
      method: 'POST',
      body: JSON.stringify({ code }),
    }),
  
  disable2FA: () => apiCall('/auth/2fa/disable', { method: 'POST' }),
};

// Investment API
export const investmentAPI = {
  getPlans: () => apiCall('/investments/plans'),
  
  getInvestments: () => apiCall('/investments'),
  
  getActiveInvestments: () => apiCall('/investments/active'),
  
  createInvestment: (data: { planId: string; amount: number }) =>
    apiCall('/investments', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  
  getDashboardStats: () => apiCall('/investments/stats/dashboard'),
};

// Deposit API
export const depositAPI = {
  getAddress: () => apiCall('/deposits/address'),
  
  getQRCode: (amount?: number) =>
    apiCall(`/deposits/qrcode${amount ? `?amount=${amount}` : ''}`),
  
  createDeposit: (data: { amount: number }) =>
    apiCall('/deposits', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  
  getDeposits: () => apiCall('/deposits'),
  
  checkStatus: (id: string) => apiCall(`/deposits/${id}/status`),
};

// Withdrawal API
export const withdrawalAPI = {
  createWithdrawal: (data: { amount: number; btcAddress: string }) =>
    apiCall('/withdrawals', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  
  getWithdrawals: () => apiCall('/withdrawals'),
};

// Transaction API
export const transactionAPI = {
  getTransactions: (params?: { type?: string; status?: string; limit?: number; offset?: number }) => {
    const queryParams = new URLSearchParams();
    if (params?.type) queryParams.append('type', params.type);
    if (params?.status) queryParams.append('status', params.status);
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    if (params?.offset) queryParams.append('offset', params.offset.toString());
    
    return apiCall(`/transactions?${queryParams.toString()}`);
  },
  
  getSummary: () => apiCall('/transactions/summary/stats'),
};

// Admin API
export const adminAPI = {
  getStats: () => apiCall('/admin/stats'),
  
  getUsers: (params?: { search?: string; status?: string; limit?: number; offset?: number }) => {
    const queryParams = new URLSearchParams();
    if (params?.search) queryParams.append('search', params.search);
    if (params?.status) queryParams.append('status', params.status);
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    if (params?.offset) queryParams.append('offset', params.offset.toString());
    
    return apiCall(`/admin/users?${queryParams.toString()}`);
  },
  
  getUser: (id: string) => apiCall(`/admin/users/${id}`),
  
  updateUserStatus: (id: string, status: string) =>
    apiCall(`/admin/users/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    }),
  
  getPendingWithdrawals: () => apiCall('/admin/withdrawals/pending'),
  
  approveWithdrawal: (id: string) =>
    apiCall(`/admin/withdrawals/${id}/approve`, { method: 'POST' }),
  
  rejectWithdrawal: (id: string, reason?: string) =>
    apiCall(`/admin/withdrawals/${id}/reject`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    }),
  
  getPendingDeposits: () => apiCall('/admin/deposits/pending'),
  
  confirmDeposit: (id: string) =>
    apiCall(`/admin/deposits/${id}/confirm`, { method: 'POST' }),
  
  getInvestments: (params?: { status?: string }) => {
    const queryParams = new URLSearchParams();
    if (params?.status) queryParams.append('status', params.status);
    
    return apiCall(`/admin/investments?${queryParams.toString()}`);
  },
  
  getBTCPrice: () => apiCall('/admin/btc-price'),
};

export default apiCall;
