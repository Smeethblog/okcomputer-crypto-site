import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { useCryptoStore } from '@/store/cryptoStore';
import {
  LayoutDashboard,
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  History,
  Settings,
  Shield,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Bell,
  Bitcoin,
} from 'lucide-react';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const navItems = [
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/investments', label: 'Investments', icon: TrendingUp },
  { path: '/deposit', label: 'Deposit', icon: ArrowDownLeft },
  { path: '/withdrawal', label: 'Withdrawal', icon: ArrowUpRight },
  { path: '/transactions', label: 'Transactions', icon: History },
  { path: '/settings', label: 'Settings', icon: Settings },
];

const adminNavItem = { path: '/admin', label: 'Admin Panel', icon: Shield };

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout } = useAuthStore();
  const { prices } = useCryptoStore();
  const location = useLocation();

  const btcPrice = prices.find(p => p.symbol === 'BTC');

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="min-h-screen bg-black flex">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`fixed lg:static inset-y-0 left-0 z-50 w-72 bg-[#0a0a0a] border-r border-white/10 transform transition-transform duration-300 lg:transform-none ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-white/10">
          <NavLink to="/dashboard" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#d4ff00] flex items-center justify-center">
              <Bitcoin className="w-6 h-6 text-black" />
            </div>
            <div>
              <span className="text-xl font-bold text-white">Crypto</span>
              <span className="text-xl font-bold text-[#d4ff00]">Vault</span>
            </div>
          </NavLink>
          <button 
            className="ml-auto lg:hidden text-white/60 hover:text-white"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 group ${
                  isActive 
                    ? 'bg-[#d4ff00]/10 text-[#d4ff00] border border-[#d4ff00]/30' 
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-[#d4ff00]' : 'group-hover:text-[#d4ff00]'}`} />
                <span className="font-medium">{item.label}</span>
                {isActive && <ChevronRight className="w-4 h-4 ml-auto" />}
              </NavLink>
            );
          })}

          {/* Admin Link */}
          {user?.isAdmin && (
            <NavLink
              to={adminNavItem.path}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 group ${
                location.pathname === adminNavItem.path
                  ? 'bg-[#d4ff00]/10 text-[#d4ff00] border border-[#d4ff00]/30' 
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <Shield className={`w-5 h-5 ${location.pathname === adminNavItem.path ? 'text-[#d4ff00]' : 'group-hover:text-[#d4ff00]'}`} />
              <span className="font-medium">{adminNavItem.label}</span>
            </NavLink>
          )}
        </nav>

        {/* User Profile */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/10">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#d4ff00] to-[#8aff00] flex items-center justify-center">
              <span className="text-black font-bold">
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-medium truncate">
                {user?.firstName} {user?.lastName}
              </p>
              <p className="text-white/40 text-sm truncate">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full px-4 py-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span className="text-sm font-medium">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-16 bg-[#0a0a0a]/80 backdrop-blur-xl border-b border-white/10 flex items-center px-4 lg:px-8 sticky top-0 z-30">
          <button
            className="lg:hidden text-white/60 hover:text-white mr-4"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-6 h-6" />
          </button>

          {/* Breadcrumb */}
          <div className="hidden md:flex items-center text-white/40 text-sm">
            <span className="text-white/60">Dashboard</span>
            <ChevronRight className="w-4 h-4 mx-2" />
            <span className="text-[#d4ff00]">
              {location.pathname.split('/')[1].charAt(0).toUpperCase() + location.pathname.split('/')[1].slice(1)}
            </span>
          </div>

          <div className="flex items-center gap-4 ml-auto">
            {/* BTC Price Ticker */}
            <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-white/5 rounded-lg border border-white/10">
              <Bitcoin className="w-5 h-5 text-[#d4ff00]" />
              <span className="text-white/60 text-sm">BTC</span>
              <span className="text-white font-mono">
                ${btcPrice?.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className={`text-sm ${btcPrice && (btcPrice.changePercent24h || 0) >= 0 ? 'text-[#d4ff00]' : 'text-red-400'}`}>
                {(btcPrice?.changePercent24h || 0) >= 0 ? '+' : ''}{(btcPrice?.changePercent24h || 0).toFixed(2)}%
              </span>
            </div>

            {/* Notifications */}
            <button className="relative p-2 text-white/60 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#d4ff00] rounded-full animate-pulse"></span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 lg:p-8 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
