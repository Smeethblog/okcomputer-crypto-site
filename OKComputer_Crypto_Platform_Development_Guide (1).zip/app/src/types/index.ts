// User Types
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  isVerified: boolean;
  isAdmin: boolean;
  twoFactorEnabled: boolean;
  twoFactorSecret?: string;
  btcWalletAddress: string;
  createdAt: string;
  lastLogin?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: RegisterData) => Promise<boolean>;
  logout: () => void;
  verifyEmail: (token: string) => Promise<boolean>;
  enable2FA: (secret: string) => void;
  disable2FA: () => void;
}

export interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
}

// Investment Types
export interface Investment {
  id: string;
  userId: string;
  planName: string;
  amount: number;
  dailyReturn: number;
  totalReturn: number;
  startDate: string;
  endDate: string;
  status: 'active' | 'completed' | 'cancelled';
  profit: number;
}

export interface InvestmentPlan {
  id: string;
  name: string;
  description: string;
  minAmount: number;
  maxAmount: number;
  dailyReturnPercent: number;
  duration: number; // in days
  features: string[];
}

// Transaction Types
export interface Transaction {
  id: string;
  userId: string;
  type: 'deposit' | 'withdrawal' | 'investment' | 'profit' | 'referral';
  amount: number;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  createdAt: string;
  completedAt?: string;
  description?: string;
  txHash?: string;
  btcAddress?: string;
}

// Deposit Types
export interface Deposit {
  id: string;
  userId: string;
  amount: number;
  btcAmount: number;
  btcAddress: string;
  status: 'pending' | 'confirming' | 'completed' | 'failed';
  confirmations: number;
  requiredConfirmations: number;
  createdAt: string;
  completedAt?: string;
  txHash?: string;
}

// Withdrawal Types
export interface Withdrawal {
  id: string;
  userId: string;
  amount: number;
  btcAmount: number;
  btcAddress: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: string;
  completedAt?: string;
  txHash?: string;
  fee: number;
}

// Crypto Price Types
export interface CryptoPrice {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  changePercent24h: number;
  volume24h: number;
  marketCap: number;
  high24h: number;
  low24h: number;
  lastUpdated: string;
}

// Dashboard Stats
export interface DashboardStats {
  totalBalance: number;
  totalInvested: number;
  totalProfit: number;
  activeInvestments: number;
  totalDeposits: number;
  totalWithdrawals: number;
  pendingWithdrawals: number;
}

// Admin Types
export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalInvestments: number;
  totalDeposits: number;
  totalWithdrawals: number;
  pendingWithdrawals: number;
  pendingDeposits: number;
}

// Notification Types
export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  isRead: boolean;
  createdAt: string;
}

// Chart Data
export interface ChartDataPoint {
  date: string;
  value: number;
  profit?: number;
  investment?: number;
}

// Settings
export interface UserSettings {
  emailNotifications: boolean;
  smsNotifications: boolean;
  twoFactorEnabled: boolean;
  language: string;
  currency: string;
  timezone: string;
}
