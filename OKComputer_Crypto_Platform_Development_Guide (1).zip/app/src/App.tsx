import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore, initializeAuth } from '@/store/authStore';
import { useCryptoStore } from '@/store/cryptoStore';
import { Toaster } from '@/components/ui/sonner';

// Pages
import LandingPage from '@/pages/LandingPage';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import DashboardPage from '@/pages/DashboardPage';
import InvestmentsPage from '@/pages/InvestmentsPage';
import DepositPage from '@/pages/DepositPage';
import WithdrawalPage from '@/pages/WithdrawalPage';
import TransactionsPage from '@/pages/TransactionsPage';
import SettingsPage from '@/pages/SettingsPage';
import AdminPage from '@/pages/AdminPage';

// Components
import ProtectedRoute from '@/components/ProtectedRoute';
import AdminRoute from '@/components/AdminRoute';

function App() {
  const { isAuthenticated } = useAuthStore();
  const { startPriceUpdates, stopPriceUpdates } = useCryptoStore();

  useEffect(() => {
    // Initialize auth state from localStorage
    initializeAuth();
    
    // Start crypto price updates
    startPriceUpdates();
    
    return () => stopPriceUpdates();
  }, [startPriceUpdates, stopPriceUpdates]);

  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        <Route 
          path="/login" 
          element={isAuthenticated ? <Navigate to="/dashboard" /> : <LoginPage />} 
        />
        <Route 
          path="/register" 
          element={isAuthenticated ? <Navigate to="/dashboard" /> : <RegisterPage />} 
        />

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/investments" element={<InvestmentsPage />} />
          <Route path="/deposit" element={<DepositPage />} />
          <Route path="/withdrawal" element={<WithdrawalPage />} />
          <Route path="/transactions" element={<TransactionsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>

        {/* Admin Routes */}
        <Route element={<AdminRoute />}>
          <Route path="/admin" element={<AdminPage />} />
        </Route>

        {/* Catch all */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      <Toaster 
        position="top-right" 
        toastOptions={{
          style: {
            background: '#0a0a0a',
            border: '1px solid rgba(212, 255, 0, 0.3)',
            color: '#fff',
          },
        }}
      />
    </BrowserRouter>
  );
}

export default App;
