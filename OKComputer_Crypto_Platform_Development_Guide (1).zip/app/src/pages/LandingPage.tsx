import { useEffect, useRef } from 'react';
import { NavLink } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Bitcoin, 
  TrendingUp, 
  Shield, 
  Zap, 
  Globe, 
  Clock,
  ArrowRight,
  Check,
  Star,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';
import { useState } from 'react';
import { useCryptoStore } from '@/store/cryptoStore';

gsap.registerPlugin(ScrollTrigger);

// Hero Section Component
function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const descRef = useRef<HTMLParagraphElement>(null);
  const buttonsRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(titleRef.current,
        { y: 100, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, delay: 0.2, ease: 'expo.out' }
      );

      // Description animation
      gsap.fromTo(descRef.current,
        { x: -20, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.8, delay: 0.4, ease: 'quad.out' }
      );

      // Buttons animation
      gsap.fromTo(buttonsRef.current,
        { scale: 0, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.6, delay: 0.6, ease: 'elastic.out(1, 0.5)' }
      );

      // Image animation
      gsap.fromTo(imageRef.current,
        { rotateY: 45, z: -500, opacity: 0 },
        { rotateY: 0, z: 0, opacity: 1, duration: 1.5, delay: 0.3, ease: 'expo.out' }
      );

      // Floating animation for image
      gsap.to(imageRef.current, {
        y: -10,
        duration: 3,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut'
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={heroRef} className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 bg-grid opacity-50" />
      
      {/* Gradient Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#d4ff00]/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#d4ff00]/5 rounded-full blur-[120px]" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#d4ff00]/10 border border-[#d4ff00]/30 rounded-full">
              <span className="w-2 h-2 bg-[#d4ff00] rounded-full animate-pulse" />
              <span className="text-[#d4ff00] text-sm font-medium">New: AI-Powered Trading</span>
            </div>

            <h1 
              ref={titleRef}
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-tight"
            >
              Maximize Your Wealth with{' '}
              <span className="text-[#d4ff00] text-glow">Intelligent</span> Crypto Investment
            </h1>

            <p 
              ref={descRef}
              className="text-lg sm:text-xl text-white/60 max-w-xl"
            >
              Automated portfolio management, real-time analytics, and secure trading—all in one powerful dashboard. Start your journey to financial freedom today.
            </p>

            <div ref={buttonsRef} className="flex flex-wrap gap-4">
              <NavLink to="/register" className="btn-primary flex items-center gap-2 text-lg">
                Start Investing
                <ArrowRight className="w-5 h-5" />
              </NavLink>
              <NavLink to="/login" className="btn-secondary flex items-center gap-2 text-lg">
                View Demo
              </NavLink>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-8 border-t border-white/10">
              <div>
                <p className="text-3xl font-bold text-[#d4ff00]">$2.5B+</p>
                <p className="text-white/40 text-sm">Assets Managed</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#d4ff00]">150K+</p>
                <p className="text-white/40 text-sm">Active Investors</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#d4ff00]">99.9%</p>
                <p className="text-white/40 text-sm">Uptime</p>
              </div>
            </div>
          </div>

          {/* Dashboard Preview */}
          <div 
            ref={imageRef}
            className="relative perspective-1000 hidden lg:block"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-br from-[#d4ff00]/20 to-transparent opacity-50" />
              <img 
                src="https://images.unsplash.com/photo-1642790106117-e829e14a795f?w=1200&h=800&fit=crop" 
                alt="CryptoVault Dashboard"
                className="w-full h-auto"
              />
              
              {/* Floating Cards */}
              <div className="absolute top-4 right-4 glass-card p-4 animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#d4ff00]/20 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-[#d4ff00]" />
                  </div>
                  <div>
                    <p className="text-white/60 text-xs">Daily Profit</p>
                    <p className="text-[#d4ff00] font-bold">+$1,245.80</p>
                  </div>
                </div>
              </div>

              <div className="absolute bottom-4 left-4 glass-card p-4 animate-float" style={{ animationDelay: '1s' }}>
                <div className="flex items-center gap-3">
                  <Bitcoin className="w-8 h-8 text-[#d4ff00]" />
                  <div>
                    <p className="text-white/60 text-xs">BTC Balance</p>
                    <p className="text-white font-bold">2.458 BTC</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Features Section
function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeFeature, setActiveFeature] = useState(0);

  const features = [
    {
      icon: TrendingUp,
      title: 'Real-Time Analytics',
      description: 'Track every market movement with millisecond precision. Our advanced charts and indicators help you make informed decisions.',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=500&fit=crop',
    },
    {
      icon: Shield,
      title: 'Secure Trading',
      description: 'Bank-grade encryption for every transaction. Your assets are protected by multi-signature wallets and cold storage.',
      image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&h=500&fit=crop',
    },
    {
      icon: Zap,
      title: 'Portfolio Management',
      description: 'Unified view of all your digital assets. Track performance, allocate funds, and rebalance with ease.',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=500&fit=crop',
    },
    {
      icon: Globe,
      title: 'Automated Investing',
      description: 'Set strategies and let the AI optimize your gains. Dollar-cost averaging and smart rebalancing included.',
      image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=500&fit=crop',
    },
    {
      icon: Clock,
      title: '24/7 Support',
      description: 'Global support team always available. Get help via chat, email, or phone whenever you need it.',
      image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=800&h=500&fit=crop',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.feature-item',
        { x: -50, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.1,
          ease: 'back.out(1.7)',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 px-4 sm:px-6 lg:px-12 xl:px-20">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
          Powerful <span className="text-[#d4ff00]">Features</span>
        </h2>
        <p className="text-white/60 text-lg max-w-2xl mx-auto">
          Everything you need to succeed in the crypto market, all in one platform.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-12 items-start max-w-7xl mx-auto">
        {/* Feature List */}
        <div className="space-y-4">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <button
                key={index}
                onClick={() => setActiveFeature(index)}
                className={`feature-item w-full text-left p-6 rounded-xl border transition-all duration-300 ${
                  activeFeature === index
                    ? 'bg-[#d4ff00]/10 border-[#d4ff00]/50'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${
                    activeFeature === index ? 'bg-[#d4ff00]' : 'bg-white/10'
                  }`}>
                    <Icon className={`w-6 h-6 ${activeFeature === index ? 'text-black' : 'text-[#d4ff00]'}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className={`text-xl font-semibold mb-2 ${
                      activeFeature === index ? 'text-[#d4ff00]' : 'text-white'
                    }`}>
                      {feature.title}
                    </h3>
                    <p className="text-white/60 text-sm">{feature.description}</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 transition-transform ${
                    activeFeature === index ? 'text-[#d4ff00] rotate-90' : 'text-white/40'
                  }`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Feature Image */}
        <div className="relative lg:sticky lg:top-24">
          <div className="relative rounded-2xl overflow-hidden border border-white/10">
            <div className="absolute inset-0 bg-gradient-to-br from-[#d4ff00]/10 to-transparent" />
            <img 
              src={features[activeFeature].image}
              alt={features[activeFeature].title}
              className="w-full h-auto transition-opacity duration-500"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

// How It Works Section
function HowItWorksSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  const steps = [
    {
      number: '01',
      title: 'Create Your Account',
      description: 'Sign up in minutes with just your email. Verify your identity and set up two-factor authentication for added security.',
      image: 'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?w=600&h=400&fit=crop',
    },
    {
      number: '02',
      title: 'Connect Your Wallet',
      description: 'Link your existing crypto wallet or create a new one. We support Bitcoin, Ethereum, and 50+ other cryptocurrencies.',
      image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=600&h=400&fit=crop',
    },
    {
      number: '03',
      title: 'Start Investing',
      description: 'Choose from our curated investment plans or create your own strategy. Watch your portfolio grow with real-time tracking.',
      image: 'https://images.unsplash.com/photo-1642543492481-44e81e3914a7?w=600&h=400&fit=crop',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.step-card',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.2,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 px-4 sm:px-6 lg:px-12 xl:px-20 bg-[#0a0a0a]">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
          How It <span className="text-[#d4ff00]">Works</span>
        </h2>
        <p className="text-white/60 text-lg max-w-2xl mx-auto">
          Get started in three simple steps and begin your crypto investment journey.
        </p>
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="relative">
          {/* Connection Line */}
          <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-[#d4ff00] via-[#d4ff00]/50 to-transparent hidden lg:block" />

          <div className="space-y-12">
            {steps.map((step, index) => (
              <div key={index} className="step-card relative grid lg:grid-cols-2 gap-8 items-center">
                {/* Number & Content */}
                <div className={`flex gap-8 ${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                  <div className="hidden lg:flex flex-col items-center">
                    <div className="w-16 h-16 rounded-full bg-[#d4ff00] flex items-center justify-center text-black font-bold text-xl z-10">
                      {step.number}
                    </div>
                  </div>
                  <div className="flex-1">
                    <span className="lg:hidden text-[#d4ff00] font-bold text-lg">{step.number}</span>
                    <h3 className="text-2xl font-bold text-white mb-4">{step.title}</h3>
                    <p className="text-white/60">{step.description}</p>
                  </div>
                </div>

                {/* Image */}
                <div className={`relative rounded-xl overflow-hidden border border-white/10 ${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <div className="absolute inset-0 bg-gradient-to-br from-[#d4ff00]/10 to-transparent" />
                  <img src={step.image} alt={step.title} className="w-full h-64 object-cover" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Pricing Section
function PricingSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  const plans = [
    {
      name: 'Basic',
      price: 9,
      description: 'Perfect for beginners',
      features: [
        'Up to $5,000 investment',
        '1.5% daily returns',
        '30-day plans',
        'Email support',
        'Basic analytics',
      ],
      highlighted: false,
    },
    {
      name: 'Pro',
      price: 29,
      description: 'For serious investors',
      features: [
        'Up to $25,000 investment',
        '2.0% daily returns',
        '45-day plans',
        'Priority support',
        'Advanced analytics',
        'API access',
        'Weekly reports',
      ],
      highlighted: true,
    },
    {
      name: 'Enterprise',
      price: 99,
      description: 'Maximum returns',
      features: [
        'Up to $100,000 investment',
        '2.5% daily returns',
        '60-day plans',
        'VIP support',
        'Personal account manager',
        'Custom strategies',
        'Full API access',
      ],
      highlighted: false,
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.pricing-card',
        { rotateY: 90, opacity: 0 },
        {
          rotateY: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.2,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 px-4 sm:px-6 lg:px-12 xl:px-20">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
          Investment <span className="text-[#d4ff00]">Plans</span>
        </h2>
        <p className="text-white/60 text-lg max-w-2xl mx-auto">
          Choose the plan that fits your investment goals. Upgrade or downgrade anytime.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto" style={{ perspective: '1200px' }}>
        {plans.map((plan, index) => (
          <div
            key={index}
            className={`pricing-card relative rounded-2xl p-8 transition-all duration-500 hover:scale-105 ${
              plan.highlighted
                ? 'bg-gradient-to-b from-[#d4ff00]/20 to-[#d4ff00]/5 border-2 border-[#d4ff00] scale-105'
                : 'bg-white/5 border border-white/10 hover:border-[#d4ff00]/50'
            }`}
            style={{ transformStyle: 'preserve-3d' }}
          >
            {plan.highlighted && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#d4ff00] text-black text-sm font-bold rounded-full">
                Most Popular
              </div>
            )}

            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
              <p className="text-white/60 text-sm mb-4">{plan.description}</p>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-4xl font-bold text-[#d4ff00]">${plan.price}</span>
                <span className="text-white/60">/month</span>
              </div>
            </div>

            <ul className="space-y-4 mb-8">
              {plan.features.map((feature, fIndex) => (
                <li key={fIndex} className="flex items-center gap-3">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                    plan.highlighted ? 'bg-[#d4ff00]' : 'bg-[#d4ff00]/20'
                  }`}>
                    <Check className={`w-3 h-3 ${plan.highlighted ? 'text-black' : 'text-[#d4ff00]'}`} />
                  </div>
                  <span className="text-white/80 text-sm">{feature}</span>
                </li>
              ))}
            </ul>

            <NavLink
              to="/register"
              className={`block w-full py-3 rounded-lg text-center font-semibold transition-all duration-300 ${
                plan.highlighted
                  ? 'bg-[#d4ff00] text-black hover:shadow-lg hover:shadow-[#d4ff00]/30'
                  : 'bg-white/10 text-white hover:bg-[#d4ff00] hover:text-black'
              }`}
            >
              Get Started
            </NavLink>
          </div>
        ))}
      </div>
    </section>
  );
}

// Testimonials Section
function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  const testimonials = [
    {
      name: 'John Davidson',
      role: 'Crypto Investor',
      avatar: 'JD',
      content: 'CryptoVault has completely transformed my investment strategy. The returns are consistent and the platform is incredibly easy to use.',
      rating: 5,
    },
    {
      name: 'Sarah Mitchell',
      role: 'Day Trader',
      avatar: 'SM',
      content: 'The real-time analytics and automated trading features are game-changers. I have seen a 40% increase in my portfolio since joining.',
      rating: 5,
    },
    {
      name: 'Michael Rodriguez',
      role: 'Business Owner',
      avatar: 'MR',
      content: 'Best investment platform I have used. The security features give me peace of mind, and the support team is always helpful.',
      rating: 5,
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.testimonial-card',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.15,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 px-4 sm:px-6 lg:px-12 xl:px-20 bg-[#0a0a0a]">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
          What Our <span className="text-[#d4ff00]">Investors</span> Say
        </h2>
        <p className="text-white/60 text-lg max-w-2xl mx-auto">
          Join thousands of satisfied investors who trust CryptoVault with their portfolios.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {testimonials.map((testimonial, index) => (
          <div
            key={index}
            className="testimonial-card glass-card p-8 hover:border-[#d4ff00]/30 transition-all duration-300"
          >
            {/* Rating */}
            <div className="flex gap-1 mb-4">
              {[...Array(testimonial.rating)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-[#d4ff00] text-[#d4ff00]" />
              ))}
            </div>

            {/* Content */}
            <p className="text-white/80 mb-6 leading-relaxed">
              "{testimonial.content}"
            </p>

            {/* Author */}
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#d4ff00] to-[#8aff00] flex items-center justify-center">
                <span className="text-black font-bold">{testimonial.avatar}</span>
              </div>
              <div>
                <p className="text-white font-semibold">{testimonial.name}</p>
                <p className="text-white/60 text-sm">{testimonial.role}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// FAQ Section
function FAQSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'How do I get started with CryptoVault?',
      answer: 'Getting started is easy! Simply create an account, verify your email, and make your first deposit. You can start investing with as little as $100.',
    },
    {
      question: 'Is my investment secure?',
      answer: 'Absolutely. We use bank-grade encryption, multi-signature wallets, and cold storage for the majority of our assets. Your funds are protected by industry-leading security measures.',
    },
    {
      question: 'What are the daily returns?',
      answer: 'Daily returns vary by plan: Basic (1.5%), Pro (2.0%), and Enterprise (2.5%). Returns are calculated and credited to your account every 24 hours.',
    },
    {
      question: 'How do I withdraw my funds?',
      answer: 'You can request a withdrawal at any time from your dashboard. Withdrawals are processed within 24 hours and sent to your registered wallet address.',
    },
    {
      question: 'Are there any hidden fees?',
      answer: 'No hidden fees. We charge a transparent 1% withdrawal fee. There are no deposit fees, maintenance fees, or other hidden charges.',
    },
    {
      question: 'Do you offer customer support?',
      answer: 'Yes! We offer 24/7 customer support via live chat, email, and phone. Our team is always ready to help you with any questions or concerns.',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.faq-item',
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 px-4 sm:px-6 lg:px-12 xl:px-20">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
          Frequently Asked <span className="text-[#d4ff00]">Questions</span>
        </h2>
        <p className="text-white/60 text-lg max-w-2xl mx-auto">
          Everything you need to know about CryptoVault.
        </p>
      </div>

      <div className="max-w-3xl mx-auto space-y-4">
        {faqs.map((faq, index) => (
          <div
            key={index}
            className="faq-item glass-card overflow-hidden"
          >
            <button
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              className="w-full flex items-center justify-between p-6 text-left"
            >
              <span className="text-white font-semibold pr-4">{faq.question}</span>
              <div className={`w-8 h-8 rounded-full bg-[#d4ff00]/20 flex items-center justify-center flex-shrink-0 transition-transform ${
                openIndex === index ? 'rotate-45' : ''
              }`}>
                <span className="text-[#d4ff00] text-xl">+</span>
              </div>
            </button>
            <div className={`overflow-hidden transition-all duration-300 ${
              openIndex === index ? 'max-h-96' : 'max-h-0'
            }`}>
              <p className="px-6 pb-6 text-white/60">{faq.answer}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// CTA Section
function CTASection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.cta-content',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 px-4 sm:px-6 lg:px-12 xl:px-20">
      <div className="cta-content relative max-w-4xl mx-auto text-center">
        {/* Background Glow */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#d4ff00]/20 via-[#d4ff00]/10 to-[#d4ff00]/20 rounded-3xl blur-3xl" />
        
        <div className="relative glass-card rounded-3xl p-12 border border-[#d4ff00]/30">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to Start Your <span className="text-[#d4ff00]">Crypto Journey</span>?
          </h2>
          <p className="text-white/60 text-lg mb-8 max-w-2xl mx-auto">
            Join over 150,000 investors who are already growing their wealth with CryptoVault. Sign up today and get your first month free.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <NavLink to="/register" className="btn-primary flex items-center gap-2 text-lg">
              Create Free Account
              <ArrowRight className="w-5 h-5" />
            </NavLink>
            <NavLink to="/login" className="btn-secondary flex items-center gap-2 text-lg">
              Sign In
            </NavLink>
          </div>
        </div>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  const { prices } = useCryptoStore();

  const footerLinks = {
    Product: ['Features', 'Pricing', 'Security', 'API'],
    Company: ['About', 'Blog', 'Careers', 'Press'],
    Resources: ['Documentation', 'Help Center', 'Community', 'Contact'],
    Legal: ['Privacy', 'Terms', 'Cookie Policy', 'Licenses'],
  };

  return (
    <footer className="bg-[#0a0a0a] border-t border-white/10 pt-16 pb-8 px-4 sm:px-6 lg:px-12 xl:px-20">
      {/* Crypto Ticker */}
      <div className="mb-12 overflow-hidden">
        <div className="flex gap-8 animate-marquee">
          {prices.map((price, index) => (
            <div key={index} className="flex items-center gap-3 flex-shrink-0">
              <span className="text-white font-semibold">{price.symbol}</span>
              <span className="text-white/60">${price.price.toLocaleString()}</span>
              <span className={`text-sm ${price.changePercent24h >= 0 ? 'text-[#d4ff00]' : 'text-red-400'}`}>
                {price.changePercent24h >= 0 ? '+' : ''}{price.changePercent24h.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-12 mb-12">
        {/* Brand */}
        <div className="lg:col-span-2">
          <NavLink to="/" className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-[#d4ff00] flex items-center justify-center">
              <Bitcoin className="w-6 h-6 text-black" />
            </div>
            <div>
              <span className="text-xl font-bold text-white">Crypto</span>
              <span className="text-xl font-bold text-[#d4ff00]">Vault</span>
            </div>
          </NavLink>
          <p className="text-white/60 mb-6 max-w-sm">
            The most secure and profitable crypto investment platform. Start growing your wealth today.
          </p>
          <div className="flex gap-4">
            {['Twitter', 'Discord', 'Telegram', 'GitHub'].map((social) => (
              <a
                key={social}
                href="#"
                className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-white/60 hover:bg-[#d4ff00] hover:text-black transition-all duration-300"
              >
                <span className="text-xs font-bold">{social[0]}</span>
              </a>
            ))}
          </div>
        </div>

        {/* Links */}
        {Object.entries(footerLinks).map(([category, links]) => (
          <div key={category}>
            <h4 className="text-white font-semibold mb-4">{category}</h4>
            <ul className="space-y-3">
              {links.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-white/60 hover:text-[#d4ff00] transition-colors"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Bottom */}
      <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-white/40 text-sm">
          © 2024 CryptoVault. All rights reserved.
        </p>
        <div className="flex items-center gap-6">
          <a href="#" className="text-white/40 hover:text-[#d4ff00] text-sm transition-colors">
            Privacy Policy
          </a>
          <a href="#" className="text-white/40 hover:text-[#d4ff00] text-sm transition-colors">
            Terms of Service
          </a>
          <a href="#" className="text-white/40 hover:text-[#d4ff00] text-sm transition-colors">
            Cookie Settings
          </a>
        </div>
      </div>
    </footer>
  );
}

// Navigation
function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Features', href: '#features' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'Testimonials', href: '#testimonials' },
    { label: 'FAQ', href: '#faq' },
  ];

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-black/80 backdrop-blur-xl border-b border-white/10' : ''
      }`}>
        <div className="px-4 sm:px-6 lg:px-12 xl:px-20">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <NavLink to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#d4ff00] flex items-center justify-center">
                <Bitcoin className="w-6 h-6 text-black" />
              </div>
              <div className="hidden sm:block">
                <span className="text-xl font-bold text-white">Crypto</span>
                <span className="text-xl font-bold text-[#d4ff00]">Vault</span>
              </div>
            </NavLink>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="text-white/60 hover:text-[#d4ff00] transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="hidden lg:flex items-center gap-4">
              <NavLink to="/login" className="text-white/60 hover:text-white transition-colors">
                Sign In
              </NavLink>
              <NavLink to="/register" className="btn-primary">
                Get Started
              </NavLink>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="lg:hidden text-white"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" />
          <div className="relative flex flex-col items-center justify-center h-full gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="text-2xl text-white hover:text-[#d4ff00] transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="flex flex-col gap-4 mt-8">
              <NavLink to="/login" className="btn-secondary" onClick={() => setMobileOpen(false)}>
                Sign In
              </NavLink>
              <NavLink to="/register" className="btn-primary" onClick={() => setMobileOpen(false)}>
                Get Started
              </NavLink>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// Main Landing Page
export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black">
      <Navigation />
      <HeroSection />
      <div id="features">
        <FeaturesSection />
      </div>
      <div id="how-it-works">
        <HowItWorksSection />
      </div>
      <div id="pricing">
        <PricingSection />
      </div>
      <div id="testimonials">
        <TestimonialsSection />
      </div>
      <div id="faq">
        <FAQSection />
      </div>
      <CTASection />
      <Footer />
    </div>
  );
}
