import { useState, useEffect } from 'react';
import { useTransactionStore } from '@/store/transactionStore';
import { 
  ArrowDownLeft, 
  ArrowUpRight, 
  TrendingUp, 
  DollarSign,
  Users,
  Filter,
  Search,
  Download,
  ChevronLeft,
  ChevronRight,
  Clock
} from 'lucide-react';

type TransactionType = 'all' | 'deposit' | 'withdrawal' | 'investment' | 'profit' | 'referral';
type TransactionStatus = 'all' | 'pending' | 'completed' | 'failed';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  status: string;
  description: string;
  createdAt: string;
}

export default function TransactionsPage() {
  const { transactions, summary, fetchTransactions, fetchSummary } = useTransactionStore();
  
  const [typeFilter, setTypeFilter] = useState<TransactionType>('all');
  const [statusFilter, setStatusFilter] = useState<TransactionStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    fetchTransactions();
    fetchSummary();
  }, [fetchTransactions, fetchSummary]);

  // Filter transactions
  const filteredTransactions = transactions.filter((transaction: Transaction) => {
    const matchesType = typeFilter === 'all' || transaction.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || transaction.status === statusFilter;
    const matchesSearch = 
      searchQuery === '' || 
      transaction.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesStatus && matchesSearch;
  });

  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return <ArrowDownLeft className="w-5 h-5 text-[#d4ff00]" />;
      case 'withdrawal':
        return <ArrowUpRight className="w-5 h-5 text-red-400" />;
      case 'investment':
        return <TrendingUp className="w-5 h-5 text-blue-400" />;
      case 'profit':
        return <DollarSign className="w-5 h-5 text-[#d4ff00]" />;
      case 'referral':
        return <Users className="w-5 h-5 text-purple-400" />;
      default:
        return <Clock className="w-5 h-5 text-white/60" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <span className="badge-success text-xs">Completed</span>;
      case 'pending':
        return <span className="badge-pending text-xs">Pending</span>;
      case 'failed':
        return <span className="badge-error text-xs">Failed</span>;
      default:
        return <span className="px-2 py-1 rounded-full text-xs bg-white/10 text-white/60">{status}</span>;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Transactions</h1>
          <p className="text-white/60 mt-1">
            View and manage all your transactions.
          </p>
        </div>
        <button className="btn-secondary flex items-center gap-2">
          <Download className="w-4 h-4" />
          Export CSV
        </button>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="glass-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-[#d4ff00]/10 flex items-center justify-center">
              <ArrowDownLeft className="w-5 h-5 text-[#d4ff00]" />
            </div>
            <span className="text-white/60">Total Deposits</span>
          </div>
          <p className="text-2xl font-bold text-[#d4ff00]">${(summary?.deposits || 0).toLocaleString()}</p>
        </div>
        <div className="glass-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
              <ArrowUpRight className="w-5 h-5 text-red-400" />
            </div>
            <span className="text-white/60">Total Withdrawals</span>
          </div>
          <p className="text-2xl font-bold text-red-400">${(summary?.withdrawals || 0).toLocaleString()}</p>
        </div>
        <div className="glass-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-[#d4ff00]/10 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-[#d4ff00]" />
            </div>
            <span className="text-white/60">Total Profit</span>
          </div>
          <p className="text-2xl font-bold text-[#d4ff00]">${(summary?.profits || 0).toLocaleString()}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="glass-card rounded-xl p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search transactions..."
              className="input-dark w-full pl-12"
            />
          </div>

          {/* Type Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-white/40" />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as TransactionType)}
              className="input-dark"
            >
              <option value="all">All Types</option>
              <option value="deposit">Deposits</option>
              <option value="withdrawal">Withdrawals</option>
              <option value="investment">Investments</option>
              <option value="profit">Profits</option>
              <option value="referral">Referrals</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as TransactionStatus)}
              className="input-dark"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
              <option value="failed">Failed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white/5">
              <tr>
                <th className="text-left text-white/60 text-sm font-medium p-4">Transaction</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Type</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Amount</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Status</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {paginatedTransactions.length > 0 ? (
                paginatedTransactions.map((transaction: Transaction) => (
                  <tr key={transaction.id} className="hover:bg-white/5 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                          {getTransactionIcon(transaction.type)}
                        </div>
                        <div>
                          <p className="text-white font-medium capitalize">{transaction.type}</p>
                          <p className="text-white/40 text-sm">{transaction.description}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-white/80 capitalize">{transaction.type}</span>
                    </td>
                    <td className="p-4">
                      <span className={`font-medium ${
                        transaction.type === 'withdrawal' ? 'text-red-400' : 'text-[#d4ff00]'
                      }`}>
                        {transaction.type === 'withdrawal' ? '-' : '+'}${transaction.amount.toLocaleString()}
                      </span>
                    </td>
                    <td className="p-4">
                      {getStatusBadge(transaction.status)}
                    </td>
                    <td className="p-4">
                      <span className="text-white/60 text-sm">
                        {formatDate(transaction.createdAt)}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="p-12 text-center">
                    <Clock className="w-12 h-12 text-white/20 mx-auto mb-4" />
                    <p className="text-white/40">No transactions found</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-white/10">
            <p className="text-white/60 text-sm">
              Showing {(currentPage - 1) * itemsPerPage + 1} to{' '}
              {Math.min(currentPage * itemsPerPage, filteredTransactions.length)} of{' '}
              {filteredTransactions.length} transactions
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-2 rounded-lg bg-white/5 text-white/60 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <span className="text-white px-4">
                {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-2 rounded-lg bg-white/5 text-white/60 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
