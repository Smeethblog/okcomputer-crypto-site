import { useState, useEffect } from 'react';
import { useInvestmentStore } from '@/store/investmentStore';
import { 
  TrendingUp, 
  Check, 
  Clock, 
  DollarSign, 
  Calendar,
  ArrowRight,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface InvestmentPlan {
  id: string;
  name: string;
  description: string;
  minAmount: number;
  maxAmount: number;
  dailyReturnPercent: number;
  duration: number;
  features: string[];
}

interface Investment {
  id: string;
  planName: string;
  amount: number;
  dailyReturn: number;
  totalReturn: number;
  profit: number;
  startDate: string;
  endDate: string;
  status: string;
}

// Investment Plan Card
function PlanCard({ 
  plan, 
  onSelect 
}: { 
  plan: InvestmentPlan; 
  onSelect: (plan: InvestmentPlan) => void;
}) {
  return (
    <div className="glass-card rounded-xl p-6 hover:border-[#d4ff00]/30 transition-all duration-300">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-xl font-bold text-white">{plan.name}</h3>
          <p className="text-white/60 text-sm mt-1">{plan.description}</p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-[#d4ff00]/10 flex items-center justify-center">
          <TrendingUp className="w-6 h-6 text-[#d4ff00]" />
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-baseline gap-1">
          <span className="text-4xl font-bold text-[#d4ff00]">{plan.dailyReturnPercent}%</span>
          <span className="text-white/60">daily</span>
        </div>
        <p className="text-white/40 text-sm">for {plan.duration} days</p>
      </div>

      <div className="space-y-3 mb-6">
        <div className="flex items-center gap-3">
          <DollarSign className="w-4 h-4 text-[#d4ff00]" />
          <span className="text-white/80 text-sm">
            ${plan.minAmount.toLocaleString()} - ${plan.maxAmount.toLocaleString()}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <Calendar className="w-4 h-4 text-[#d4ff00]" />
          <span className="text-white/80 text-sm">{plan.duration} days duration</span>
        </div>
      </div>

      <ul className="space-y-2 mb-6">
        {plan.features.map((feature: string, index: number) => (
          <li key={index} className="flex items-center gap-2">
            <Check className="w-4 h-4 text-[#d4ff00]" />
            <span className="text-white/60 text-sm">{feature}</span>
          </li>
        ))}
      </ul>

      <button
        onClick={() => onSelect(plan)}
        className="btn-primary w-full flex items-center justify-center gap-2"
      >
        Select Plan
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
}

// Active Investment Card
function ActiveInvestmentCard({ investment }: { investment: Investment }) {
  const progress = (investment.profit / investment.totalReturn) * 100;
  const daysLeft = Math.ceil(
    (new Date(investment.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
  );

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-white">{investment.planName}</h3>
          <p className="text-white/60 text-sm">
            Started {new Date(investment.startDate).toLocaleDateString()}
          </p>
        </div>
        <span className="badge-success">Active</span>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-4">
        <div>
          <p className="text-white/40 text-xs mb-1">Invested</p>
          <p className="text-white font-semibold">${investment.amount.toLocaleString()}</p>
        </div>
        <div>
          <p className="text-white/40 text-xs mb-1">Daily Return</p>
          <p className="text-[#d4ff00] font-semibold">+${investment.dailyReturn.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-white/40 text-xs mb-1">Total Profit</p>
          <p className="text-[#d4ff00] font-semibold">${investment.profit.toFixed(2)}</p>
        </div>
      </div>

      <div className="mb-2">
        <div className="flex items-center justify-between text-sm mb-1">
          <span className="text-white/60">Progress</span>
          <span className="text-[#d4ff00]">{progress.toFixed(1)}%</span>
        </div>
        <div className="h-2 bg-white/10 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-[#d4ff00] to-[#8aff00] rounded-full transition-all duration-500"
            style={{ width: `${Math.min(progress, 100)}%` }}
          />
        </div>
      </div>

      <div className="flex items-center gap-2 text-white/40 text-sm">
        <Clock className="w-4 h-4" />
        <span>{daysLeft} days remaining</span>
      </div>
    </div>
  );
}

// Investment Modal
function InvestmentModal({
  plan,
  isOpen,
  onClose,
  onConfirm,
}: {
  plan: InvestmentPlan | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (amount: number) => void;
}) {
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');

  if (!plan) return null;

  const handleSubmit = () => {
    const numAmount = parseFloat(amount);
    
    if (!numAmount || isNaN(numAmount)) {
      setError('Please enter a valid amount');
      return;
    }

    if (numAmount < plan.minAmount) {
      setError(`Minimum investment is $${plan.minAmount.toLocaleString()}`);
      return;
    }

    if (numAmount > plan.maxAmount) {
      setError(`Maximum investment is $${plan.maxAmount.toLocaleString()}`);
      return;
    }

    onConfirm(numAmount);
    setAmount('');
    setError('');
    onClose();
  };

  const dailyReturn = amount ? (parseFloat(amount) * plan.dailyReturnPercent) / 100 : 0;
  const totalReturn = dailyReturn * plan.duration;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#0a0a0a] border border-white/10 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#d4ff00]/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-[#d4ff00]" />
            </div>
            {plan.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <label className="block text-white/80 text-sm font-medium mb-2">
              Investment Amount
            </label>
            <div className="relative">
              <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
              <input
                type="number"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setError('');
                }}
                placeholder={`${plan.minAmount} - ${plan.maxAmount}`}
                className="input-dark w-full pl-12"
              />
            </div>
            {error && (
              <p className="text-red-400 text-sm mt-2 flex items-center gap-1">
                <AlertCircle className="w-4 h-4" />
                {error}
              </p>
            )}
            <p className="text-white/40 text-sm mt-2">
              Min: ${plan.minAmount.toLocaleString()} | Max: ${plan.maxAmount.toLocaleString()}
            </p>
          </div>

          {amount && !error && (
            <div className="bg-white/5 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-white/60">Daily Return ({plan.dailyReturnPercent}%)</span>
                <span className="text-[#d4ff00] font-semibold">+${dailyReturn.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/60">Duration</span>
                <span className="text-white">{plan.duration} days</span>
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-white/10">
                <span className="text-white font-semibold">Total Return</span>
                <span className="text-[#d4ff00] font-bold text-xl">+${totalReturn.toFixed(2)}</span>
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 btn-secondary"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={!amount || !!error}
              className="flex-1 btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Confirm Investment
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Main Investments Page
export default function InvestmentsPage() {
  const { investments, activeInvestments, plans, fetchInvestments, fetchActiveInvestments, fetchPlans, createInvestment } = useInvestmentStore();
  const [selectedPlan, setSelectedPlan] = useState<InvestmentPlan | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    fetchInvestments();
    fetchActiveInvestments();
    fetchPlans();
  }, [fetchInvestments, fetchActiveInvestments, fetchPlans]);

  const handleSelectPlan = (plan: InvestmentPlan) => {
    setSelectedPlan(plan);
    setIsModalOpen(true);
  };

  const handleConfirmInvestment = async (amount: number) => {
    try {
      await createInvestment(selectedPlan?.id || '', amount);
      toast.success('Investment created successfully!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to create investment');
    }
  };

  const completedInvestments = investments.filter((inv: Investment) => inv.status === 'completed');

  const totalInvested = investments.reduce((sum: number, inv: Investment) => sum + inv.amount, 0);
  const totalProfit = investments.reduce((sum: number, inv: Investment) => sum + inv.profit, 0);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">Investments</h1>
        <p className="text-white/60 mt-1">
          Manage your investments and explore new opportunities.
        </p>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="glass-card p-6">
          <p className="text-white/60 text-sm mb-1">Active Investments</p>
          <p className="text-3xl font-bold text-white">{activeInvestments.length}</p>
        </div>
        <div className="glass-card p-6">
          <p className="text-white/60 text-sm mb-1">Total Invested</p>
          <p className="text-3xl font-bold text-[#d4ff00]">${totalInvested.toLocaleString()}</p>
        </div>
        <div className="glass-card p-6">
          <p className="text-white/60 text-sm mb-1">Total Profit</p>
          <p className="text-3xl font-bold text-[#d4ff00]">${totalProfit.toLocaleString()}</p>
        </div>
      </div>

      {/* Active Investments */}
      {activeInvestments.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold text-white mb-4">Active Investments</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {activeInvestments.map((investment: Investment) => (
              <ActiveInvestmentCard key={investment.id} investment={investment} />
            ))}
          </div>
        </div>
      )}

      {/* Investment Plans */}
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Investment Plans</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan: InvestmentPlan) => (
            <PlanCard key={plan.id} plan={plan} onSelect={handleSelectPlan} />
          ))}
        </div>
      </div>

      {/* Completed Investments */}
      {completedInvestments.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold text-white mb-4">Completed Investments</h2>
          <div className="glass-card rounded-xl overflow-hidden">
            <table className="w-full">
              <thead className="bg-white/5">
                <tr>
                  <th className="text-left text-white/60 text-sm font-medium p-4">Plan</th>
                  <th className="text-left text-white/60 text-sm font-medium p-4">Amount</th>
                  <th className="text-left text-white/60 text-sm font-medium p-4">Profit</th>
                  <th className="text-left text-white/60 text-sm font-medium p-4">Completed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {completedInvestments.map((investment: Investment) => (
                  <tr key={investment.id} className="hover:bg-white/5">
                    <td className="p-4 text-white">{investment.planName}</td>
                    <td className="p-4 text-white">${investment.amount.toLocaleString()}</td>
                    <td className="p-4 text-[#d4ff00]">+${investment.profit.toLocaleString()}</td>
                    <td className="p-4 text-white/60">
                      {new Date(investment.endDate).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Investment Modal */}
      <InvestmentModal
        plan={selectedPlan}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedPlan(null);
        }}
        onConfirm={handleConfirmInvestment}
      />
    </div>
  );
}
