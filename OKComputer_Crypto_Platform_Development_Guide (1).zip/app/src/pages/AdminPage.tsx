import { useState } from 'react';
import { useAuthStore } from '@/store/authStore';
import { 
  Users, 
  TrendingUp, 
  ArrowDownLeft, 
  ArrowUpRight,
  Clock,
  Check,
  X,
  Search,
  Shield
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

// Mock users data
const mockUsersList = [
  { id: '1', email: 'admin@cryptovault.com', firstName: 'Admin', lastName: 'User', isVerified: true, isAdmin: true, balance: 50000, createdAt: '2024-01-01' },
  { id: '2', email: 'user@example.com', firstName: 'John', lastName: 'Doe', isVerified: true, isAdmin: false, balance: 15000, createdAt: '2024-06-01' },
  { id: '3', email: 'sarah@example.com', firstName: 'Sarah', lastName: 'Smith', isVerified: true, isAdmin: false, balance: 25000, createdAt: '2024-07-15' },
  { id: '4', email: 'mike@example.com', firstName: 'Mike', lastName: 'Johnson', isVerified: false, isAdmin: false, balance: 0, createdAt: '2024-11-20' },
  { id: '5', email: 'emma@example.com', firstName: 'Emma', lastName: 'Williams', isVerified: true, isAdmin: false, balance: 8000, createdAt: '2024-08-10' },
];

// Mock pending withdrawals
const mockPendingWithdrawals = [
  { id: 'w1', userId: '2', userName: 'John Doe', amount: 2000, btcAmount: 0.021, btcAddress: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh', createdAt: '2024-12-01T10:00:00Z' },
  { id: 'w2', userId: '3', userName: 'Sarah Smith', amount: 5000, btcAmount: 0.052, btcAddress: 'bc1qm34lsc65zpw79lxes69zkqmk6ee3ewf0j77s3h', createdAt: '2024-12-01T09:30:00Z' },
];

// Mock pending deposits
const mockPendingDeposits = [
  { id: 'd1', userId: '2', userName: 'John Doe', amount: 3000, btcAmount: 0.031, confirmations: 2, requiredConfirmations: 3, createdAt: '2024-12-01T08:00:00Z' },
];

export default function AdminPage() {
  const { user } = useAuthStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'withdrawals' | 'deposits' | 'investments'>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [showUserModal, setShowUserModal] = useState(false);

  // Stats
  const stats = {
    totalUsers: mockUsersList.length,
    activeUsers: mockUsersList.filter(u => u.balance > 0).length,
    totalDeposits: 150000,
    totalWithdrawals: 45000,
    pendingWithdrawals: mockPendingWithdrawals.length,
    pendingDeposits: mockPendingDeposits.length,
    totalInvestments: 75000,
  };

  const filteredUsers = mockUsersList.filter(u => 
    u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.lastName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleApproveWithdrawal = (_withdrawalId: string) => {
    toast.success('Withdrawal approved');
  };

  const handleRejectWithdrawal = (_withdrawalId: string) => {
    toast.error('Withdrawal rejected');
  };

  const handleConfirmDeposit = (_depositId: string) => {
    toast.success('Deposit confirmed');
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Shield },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'withdrawals', label: 'Withdrawals', icon: ArrowUpRight },
    { id: 'deposits', label: 'Deposits', icon: ArrowDownLeft },
    { id: 'investments', label: 'Investments', icon: TrendingUp },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-[#d4ff00]/10 flex items-center justify-center">
          <Shield className="w-6 h-6 text-[#d4ff00]" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-white">Admin Panel</h1>
          <p className="text-white/60">
            Welcome, {user?.firstName}. Manage your platform here.
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      {activeTab === 'overview' && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="glass-card p-6">
            <div className="flex items-center gap-3 mb-2">
              <Users className="w-5 h-5 text-[#d4ff00]" />
              <span className="text-white/60">Total Users</span>
            </div>
            <p className="text-3xl font-bold text-white">{stats.totalUsers}</p>
            <p className="text-[#d4ff00] text-sm">{stats.activeUsers} active</p>
          </div>
          <div className="glass-card p-6">
            <div className="flex items-center gap-3 mb-2">
              <ArrowDownLeft className="w-5 h-5 text-[#d4ff00]" />
              <span className="text-white/60">Total Deposits</span>
            </div>
            <p className="text-3xl font-bold text-[#d4ff00]">${stats.totalDeposits.toLocaleString()}</p>
          </div>
          <div className="glass-card p-6">
            <div className="flex items-center gap-3 mb-2">
              <ArrowUpRight className="w-5 h-5 text-red-400" />
              <span className="text-white/60">Total Withdrawals</span>
            </div>
            <p className="text-3xl font-bold text-red-400">${stats.totalWithdrawals.toLocaleString()}</p>
          </div>
          <div className="glass-card p-6">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-[#d4ff00]" />
              <span className="text-white/60">Total Investments</span>
            </div>
            <p className="text-3xl font-bold text-[#d4ff00]">${stats.totalInvestments.toLocaleString()}</p>
          </div>
          <div className="glass-card p-6 border-yellow-500/30">
            <div className="flex items-center gap-3 mb-2">
              <Clock className="w-5 h-5 text-yellow-400" />
              <span className="text-white/60">Pending Withdrawals</span>
            </div>
            <p className="text-3xl font-bold text-yellow-400">{stats.pendingWithdrawals}</p>
          </div>
          <div className="glass-card p-6 border-yellow-500/30">
            <div className="flex items-center gap-3 mb-2">
              <Clock className="w-5 h-5 text-yellow-400" />
              <span className="text-white/60">Pending Deposits</span>
            </div>
            <p className="text-3xl font-bold text-yellow-400">{stats.pendingDeposits}</p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-[#d4ff00] text-black'
                  : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="glass-card rounded-xl overflow-hidden">
          <div className="p-4 border-b border-white/10">
            <div className="flex items-center gap-4">
              <Search className="w-5 h-5 text-white/40" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search users..."
                className="bg-transparent text-white placeholder:text-white/40 flex-1 focus:outline-none"
              />
            </div>
          </div>
          <table className="w-full">
            <thead className="bg-white/5">
              <tr>
                <th className="text-left text-white/60 text-sm font-medium p-4">User</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Email</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Balance</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Status</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Joined</th>
                <th className="text-left text-white/60 text-sm font-medium p-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-white/5">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#d4ff00] to-[#8aff00] flex items-center justify-center">
                        <span className="text-black font-bold text-sm">
                          {user.firstName[0]}{user.lastName[0]}
                        </span>
                      </div>
                      <span className="text-white">{user.firstName} {user.lastName}</span>
                    </div>
                  </td>
                  <td className="p-4 text-white/80">{user.email}</td>
                  <td className="p-4 text-[#d4ff00]">${user.balance.toLocaleString()}</td>
                  <td className="p-4">
                    {user.isVerified ? (
                      <span className="badge-success text-xs">Verified</span>
                    ) : (
                      <span className="badge-pending text-xs">Pending</span>
                    )}
                  </td>
                  <td className="p-4 text-white/60">{new Date(user.createdAt).toLocaleDateString()}</td>
                  <td className="p-4">
                    <button
                      onClick={() => {
                        setSelectedUser(user);
                        setShowUserModal(true);
                      }}
                      className="text-[#d4ff00] hover:underline text-sm"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Withdrawals Tab */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4">
          {mockPendingWithdrawals.length > 0 ? (
            mockPendingWithdrawals.map((withdrawal) => (
              <div key={withdrawal.id} className="glass-card rounded-xl p-6 border-yellow-500/30">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-yellow-500/10 flex items-center justify-center">
                      <ArrowUpRight className="w-6 h-6 text-yellow-400" />
                    </div>
                    <div>
                      <p className="text-white font-semibold">${withdrawal.amount.toLocaleString()}</p>
                      <p className="text-white/60 text-sm">{withdrawal.btcAmount} BTC</p>
                      <p className="text-white/40 text-sm">{withdrawal.userName}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <code className="bg-white/5 px-3 py-2 rounded-lg text-white/60 text-sm font-mono hidden lg:block">
                      {withdrawal.btcAddress.slice(0, 20)}...{withdrawal.btcAddress.slice(-8)}
                    </code>
                    <button
                      onClick={() => handleApproveWithdrawal(withdrawal.id)}
                      className="px-4 py-2 bg-[#d4ff00] text-black rounded-lg font-medium hover:bg-[#e0ff33] transition-colors"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleRejectWithdrawal(withdrawal.id)}
                      className="px-4 py-2 bg-red-500 text-white rounded-lg font-medium hover:bg-red-600 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="glass-card rounded-xl p-12 text-center">
              <Check className="w-12 h-12 text-[#d4ff00] mx-auto mb-4" />
              <p className="text-white">No pending withdrawals</p>
            </div>
          )}
        </div>
      )}

      {/* Deposits Tab */}
      {activeTab === 'deposits' && (
        <div className="space-y-4">
          {mockPendingDeposits.length > 0 ? (
            mockPendingDeposits.map((deposit) => (
              <div key={deposit.id} className="glass-card rounded-xl p-6 border-yellow-500/30">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-yellow-500/10 flex items-center justify-center">
                      <ArrowDownLeft className="w-6 h-6 text-yellow-400" />
                    </div>
                    <div>
                      <p className="text-white font-semibold">${deposit.amount.toLocaleString()}</p>
                      <p className="text-white/60 text-sm">{deposit.btcAmount} BTC</p>
                      <p className="text-white/40 text-sm">{deposit.userName}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-white/60 text-sm">Confirmations</p>
                      <p className="text-yellow-400 font-semibold">{deposit.confirmations}/{deposit.requiredConfirmations}</p>
                    </div>
                    <button
                      onClick={() => handleConfirmDeposit(deposit.id)}
                      className="px-4 py-2 bg-[#d4ff00] text-black rounded-lg font-medium hover:bg-[#e0ff33] transition-colors"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="glass-card rounded-xl p-12 text-center">
              <Check className="w-12 h-12 text-[#d4ff00] mx-auto mb-4" />
              <p className="text-white">No pending deposits</p>
            </div>
          )}
        </div>
      )}

      {/* Investments Tab */}
      {activeTab === 'investments' && (
        <div className="glass-card rounded-xl p-12 text-center">
          <TrendingUp className="w-12 h-12 text-[#d4ff00] mx-auto mb-4" />
          <p className="text-white mb-2">Investment Management</p>
          <p className="text-white/60">View and manage all user investments</p>
        </div>
      )}

      {/* User Detail Modal */}
      <Dialog open={showUserModal} onOpenChange={setShowUserModal}>
        <DialogContent className="bg-[#0a0a0a] border border-white/10 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#d4ff00] to-[#8aff00] flex items-center justify-center">
                <span className="text-black font-bold">
                  {selectedUser?.firstName?.[0]}{selectedUser?.lastName?.[0]}
                </span>
              </div>
              {selectedUser?.firstName} {selectedUser?.lastName}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-white/60 text-sm">Email</p>
                <p className="text-white">{selectedUser?.email}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-white/60 text-sm">Balance</p>
                <p className="text-[#d4ff00] font-semibold">${selectedUser?.balance?.toLocaleString()}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-white/60 text-sm">Status</p>
                <p className="text-white">{selectedUser?.isVerified ? 'Verified' : 'Pending'}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-white/60 text-sm">Joined</p>
                <p className="text-white">{new Date(selectedUser?.createdAt).toLocaleDateString()}</p>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => {
                  toast.success('User updated');
                  setShowUserModal(false);
                }}
                className="flex-1 btn-primary"
              >
                Edit User
              </button>
              <button
                onClick={() => {
                  toast.error('User suspended');
                  setShowUserModal(false);
                }}
                className="flex-1 px-4 py-2 bg-red-500/10 text-red-400 border border-red-500/30 rounded-lg hover:bg-red-500/20 transition-colors"
              >
                Suspend
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
