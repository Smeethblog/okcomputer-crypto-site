import { useState, useEffect } from 'react';
import { useTransactionStore } from '@/store/transactionStore';
import { useInvestmentStore } from '@/store/investmentStore';
import { useCryptoStore } from '@/store/cryptoStore';
import { 
  ArrowUpRight, 
  Wallet,
  AlertCircle,
  Check,
  Clock
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface Withdrawal {
  id: string;
  amount: number;
  btcAmount: string;
  btcAddress: string;
  status: string;
  fee: number;
  createdAt: string;
}

export default function WithdrawalPage() {
  const { withdrawals, fetchWithdrawals, createWithdrawal } = useTransactionStore();
  const { stats, fetchDashboardStats } = useInvestmentStore();
  const { prices } = useCryptoStore();

  const [amount, setAmount] = useState('');
  const [btcAddress, setBtcAddress] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchWithdrawals();
    fetchDashboardStats();
  }, [fetchWithdrawals, fetchDashboardStats]);

  const btcPrice = prices.find(p => p.symbol === 'BTC');
  const availableBalance = stats?.totalBalance || 0;
  const withdrawalFee = amount ? parseFloat(amount) * 0.01 : 0;
  const netAmount = amount ? parseFloat(amount) - withdrawalFee : 0;
  const btcAmount = netAmount && btcPrice ? (netAmount / btcPrice.price).toFixed(8) : '0.00000000';

  const pendingWithdrawals = withdrawals.filter((w: Withdrawal) => w.status === 'pending' || w.status === 'processing');

  const handleMaxAmount = () => {
    setAmount(availableBalance.toString());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!amount || parseFloat(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (parseFloat(amount) > availableBalance) {
      toast.error('Insufficient balance');
      return;
    }

    if (parseFloat(amount) < 100) {
      toast.error('Minimum withdrawal is $100');
      return;
    }

    if (!btcAddress || btcAddress.length < 26) {
      toast.error('Please enter a valid Bitcoin address');
      return;
    }

    setShowConfirmModal(true);
  };

  const handleConfirmWithdrawal = async () => {
    setIsSubmitting(true);
    
    try {
      await createWithdrawal(parseFloat(amount), btcAddress);
      toast.success('Withdrawal request submitted successfully!');
      setAmount('');
      setBtcAddress('');
      setShowConfirmModal(false);
      fetchDashboardStats();
    } catch (error: any) {
      toast.error(error.message || 'Failed to submit withdrawal');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <span className="badge-success text-xs">Completed</span>;
      case 'processing':
        return <span className="badge-pending text-xs">Processing</span>;
      case 'pending':
        return <span className="badge-pending text-xs">Pending</span>;
      default:
        return <span className="badge-error text-xs">Failed</span>;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">Withdrawal</h1>
        <p className="text-white/60 mt-1">
          Withdraw your funds to your Bitcoin wallet.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Withdrawal Form */}
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-[#d4ff00]/10 flex items-center justify-center">
              <ArrowUpRight className="w-6 h-6 text-[#d4ff00]" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-white">Request Withdrawal</h2>
              <p className="text-white/60 text-sm">Minimum: $100 | Fee: 1%</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Available Balance */}
            <div className="bg-white/5 rounded-lg p-4">
              <p className="text-white/60 text-sm mb-1">Available Balance</p>
              <p className="text-2xl font-bold text-[#d4ff00]">${availableBalance.toLocaleString()}</p>
            </div>

            {/* Amount */}
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">
                Amount (USD)
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40">$</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                  className="input-dark w-full pl-10 pr-20"
                />
                <button
                  type="button"
                  onClick={handleMaxAmount}
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1 bg-[#d4ff00]/10 text-[#d4ff00] text-sm rounded hover:bg-[#d4ff00]/20 transition-colors"
                >
                  MAX
                </button>
              </div>
              {amount && (
                <p className="text-white/60 text-sm mt-2">
                  ≈ {btcAmount} BTC
                </p>
              )}
            </div>

            {/* BTC Address */}
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">
                Bitcoin Wallet Address
              </label>
              <input
                type="text"
                value={btcAddress}
                onChange={(e) => setBtcAddress(e.target.value)}
                placeholder="bc1q..."
                className="input-dark w-full"
              />
              <p className="text-white/40 text-sm mt-2">
                Double-check your address. Transactions cannot be reversed.
              </p>
            </div>

            {/* Summary */}
            {amount && (
              <div className="bg-white/5 rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-white/60">Withdrawal Amount</span>
                  <span className="text-white">${parseFloat(amount).toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/60">Fee (1%)</span>
                  <span className="text-red-400">-${withdrawalFee.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-white/10">
                  <span className="text-white font-semibold">You'll Receive</span>
                  <span className="text-[#d4ff00] font-bold">${netAmount.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/60">BTC Amount</span>
                  <span className="text-white font-mono">{btcAmount} BTC</span>
                </div>
              </div>
            )}

            {/* Warnings */}
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <div className="text-yellow-400 text-sm">
                  <p className="font-medium mb-1">Important:</p>
                  <ul className="space-y-1">
                    <li>• Minimum withdrawal: $100</li>
                    <li>• Processing time: 24-48 hours</li>
                    <li>• Ensure your wallet address is correct</li>
                  </ul>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              <ArrowUpRight className="w-5 h-5" />
              Request Withdrawal
            </button>
          </form>
        </div>

        {/* Withdrawal History */}
        <div className="space-y-6">
          <div className="glass-card rounded-xl p-6">
            <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <Wallet className="w-5 h-5 text-[#d4ff00]" />
              Withdrawal History
            </h2>
            
            {withdrawals.length > 0 ? (
              <div className="space-y-4">
                {withdrawals.map((withdrawal: Withdrawal) => (
                  <div 
                    key={withdrawal.id} 
                    className="flex items-center justify-between p-4 bg-white/5 rounded-lg"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-[#d4ff00]/10 flex items-center justify-center">
                        <ArrowUpRight className="w-5 h-5 text-[#d4ff00]" />
                      </div>
                      <div>
                        <p className="text-white font-medium">${withdrawal.amount.toLocaleString()}</p>
                        <p className="text-white/40 text-sm">{withdrawal.btcAmount} BTC</p>
                      </div>
                    </div>
                    <div className="text-right">
                      {getStatusBadge(withdrawal.status)}
                      <p className="text-white/40 text-xs mt-1">
                        {new Date(withdrawal.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Wallet className="w-12 h-12 text-white/20 mx-auto mb-4" />
                <p className="text-white/40">No withdrawals yet</p>
              </div>
            )}
          </div>

          {/* Pending Withdrawals */}
          {pendingWithdrawals.length > 0 && (
            <div className="glass-card rounded-xl p-6 border-yellow-500/30">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-yellow-400" />
                Pending Withdrawals
              </h2>
              <div className="space-y-4">
                {pendingWithdrawals.map((withdrawal: Withdrawal) => (
                  <div 
                    key={withdrawal.id} 
                    className="flex items-center justify-between p-4 bg-yellow-500/5 rounded-lg border border-yellow-500/20"
                  >
                    <div>
                      <p className="text-white font-medium">${withdrawal.amount.toLocaleString()}</p>
                      <p className="text-white/40 text-sm">{withdrawal.btcAmount} BTC</p>
                    </div>
                    <div className="text-right">
                      <span className="badge-pending text-xs">Processing</span>
                      <p className="text-white/40 text-xs mt-1">
                        {new Date(withdrawal.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Info Card */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-[#d4ff00]" />
              Withdrawal Information
            </h3>
            <ul className="space-y-3 text-white/60 text-sm">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-[#d4ff00] mt-0.5 flex-shrink-0" />
                <span>Minimum withdrawal amount is $100</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-[#d4ff00] mt-0.5 flex-shrink-0" />
                <span>1% fee applies to all withdrawals</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-[#d4ff00] mt-0.5 flex-shrink-0" />
                <span>Processing time: 24-48 hours</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-[#d4ff00] mt-0.5 flex-shrink-0" />
                <span>Verify your wallet address carefully</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <Dialog open={showConfirmModal} onOpenChange={setShowConfirmModal}>
        <DialogContent className="bg-[#0a0a0a] border border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#d4ff00]/10 flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-[#d4ff00]" />
              </div>
              Confirm Withdrawal
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
              <p className="text-red-400 text-sm">
                Please verify all details. Cryptocurrency transactions cannot be reversed once submitted.
              </p>
            </div>

            <div className="bg-white/5 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-white/60">Amount</span>
                <span className="text-white font-semibold">${parseFloat(amount).toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/60">Fee</span>
                <span className="text-red-400">-${withdrawalFee.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-white/10">
                <span className="text-white font-semibold">Net Amount</span>
                <span className="text-[#d4ff00] font-bold">${netAmount.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/60">BTC Amount</span>
                <span className="text-white font-mono">{btcAmount} BTC</span>
              </div>
              <div className="pt-3 border-t border-white/10">
                <span className="text-white/60 block mb-1">To Address</span>
                <span className="text-white font-mono text-sm break-all">{btcAddress}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 btn-secondary"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmWithdrawal}
                disabled={isSubmitting}
                className="flex-1 btn-primary flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Clock className="w-5 h-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Check className="w-5 h-5" />
                    Confirm
                  </>
                )}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
