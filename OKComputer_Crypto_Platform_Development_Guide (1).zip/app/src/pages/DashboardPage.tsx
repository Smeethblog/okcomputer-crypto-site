import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  TrendingUp, 
  ArrowDownLeft, 
  ArrowUpRight,
  Clock,
  ChevronRight,
  Bitcoin,
  Activity,
  DollarSign,
  Wallet
} from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { useInvestmentStore } from '@/store/investmentStore';
import { useTransactionStore } from '@/store/transactionStore';
import { useCryptoStore } from '@/store/cryptoStore';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

// Mock chart data (will be replaced with real data)
const chartData = [
  { date: 'Jan', value: 4000, profit: 2400 },
  { date: 'Feb', value: 3000, profit: 1398 },
  { date: 'Mar', value: 2000, profit: 9800 },
  { date: 'Apr', value: 2780, profit: 3908 },
  { date: 'May', value: 1890, profit: 4800 },
  { date: 'Jun', value: 2390, profit: 3800 },
  { date: 'Jul', value: 3490, profit: 4300 },
  { date: 'Aug', value: 4000, profit: 2400 },
  { date: 'Sep', value: 3000, profit: 1398 },
  { date: 'Oct', value: 5000, profit: 6800 },
  { date: 'Nov', value: 2780, profit: 3908 },
  { date: 'Dec', value: 6890, profit: 7800 },
];

// Stat Card Component
function StatCard({ 
  title, 
  value, 
  change, 
  changeType, 
  icon: Icon,
  linkTo 
}: { 
  title: string; 
  value: string; 
  change?: string; 
  changeType?: 'positive' | 'negative';
  icon: React.ElementType;
  linkTo?: string;
}) {
  const content = (
    <div className="glass-card p-6 hover:border-[#d4ff00]/30 transition-all duration-300 group">
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-[#d4ff00]/10 flex items-center justify-center">
          <Icon className="w-6 h-6 text-[#d4ff00]" />
        </div>
        {change && (
          <span className={`text-sm font-medium ${changeType === 'positive' ? 'text-[#d4ff00]' : 'text-red-400'}`}>
            {change}
          </span>
        )}
      </div>
      <p className="text-white/60 text-sm mb-1">{title}</p>
      <p className="text-2xl font-bold text-white">{value}</p>
      {linkTo && (
        <div className="mt-4 flex items-center gap-1 text-[#d4ff00] text-sm opacity-0 group-hover:opacity-100 transition-opacity">
          <span>View Details</span>
          <ChevronRight className="w-4 h-4" />
        </div>
      )}
    </div>
  );

  if (linkTo) {
    return <NavLink to={linkTo}>{content}</NavLink>;
  }
  return content;
}

// Recent Transaction Item
function TransactionItem({ transaction }: { transaction: any }) {
  const getIcon = () => {
    switch (transaction.type) {
      case 'deposit':
        return <ArrowDownLeft className="w-5 h-5 text-[#d4ff00]" />;
      case 'withdrawal':
        return <ArrowUpRight className="w-5 h-5 text-red-400" />;
      case 'profit':
        return <TrendingUp className="w-5 h-5 text-[#d4ff00]" />;
      default:
        return <Activity className="w-5 h-5 text-white/60" />;
    }
  };

  return (
    <div className="flex items-center justify-between p-4 hover:bg-white/5 rounded-lg transition-colors">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
          {getIcon()}
        </div>
        <div>
          <p className="text-white font-medium capitalize">{transaction.type}</p>
          <p className="text-white/40 text-sm">{transaction.description}</p>
        </div>
      </div>
      <div className="text-right">
        <p className={`font-medium ${
          transaction.type === 'withdrawal' ? 'text-red-400' : 'text-[#d4ff00]'
        }`}>
          {transaction.type === 'withdrawal' ? '-' : '+'}${parseFloat(transaction.amount).toLocaleString()}
        </p>
        <p className="text-white/40 text-xs">
          {new Date(transaction.createdAt).toLocaleDateString()}
        </p>
      </div>
    </div>
  );
}

// Crypto Price Ticker
function CryptoTicker() {
  const { prices } = useCryptoStore();

  return (
    <div className="glass-card p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-semibold flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#d4ff00]" />
          Live Prices
        </h3>
        <span className="text-white/40 text-sm">24h Change</span>
      </div>
      <div className="space-y-3">
        {prices.slice(0, 5).map((price) => (
          <div key={price.symbol} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
                <span className="text-white font-bold text-xs">{price.symbol[0]}</span>
              </div>
              <div>
                <p className="text-white font-medium">{price.symbol}</p>
                <p className="text-white/40 text-xs">{price.name}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-white font-mono">${price.price.toLocaleString()}</p>
              <p className={`text-xs ${price.changePercent24h >= 0 ? 'text-[#d4ff00]' : 'text-red-400'}`}>
                {price.changePercent24h >= 0 ? '+' : ''}{price.changePercent24h.toFixed(2)}%
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Main Dashboard Page
export default function DashboardPage() {
  const { user } = useAuthStore();
  const { stats, fetchDashboardStats } = useInvestmentStore();
  const { transactions, fetchTransactions } = useTransactionStore();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await Promise.all([
        fetchDashboardStats(),
        fetchTransactions({ limit: 5 }),
      ]);
      setIsLoading(false);
    };
    
    loadData();
    
    // Refresh data every 30 seconds
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, [fetchDashboardStats, fetchTransactions]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#d4ff00]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">
            Welcome back, <span className="text-[#d4ff00]">{user?.firstName}</span>
          </h1>
          <p className="text-white/60 mt-1">
            Here's what's happening with your investments today.
          </p>
        </div>
        <div className="flex gap-3">
          <NavLink to="/deposit" className="btn-primary flex items-center gap-2">
            <ArrowDownLeft className="w-4 h-4" />
            Deposit
          </NavLink>
          <NavLink to="/withdrawal" className="btn-secondary flex items-center gap-2">
            <ArrowUpRight className="w-4 h-4" />
            Withdraw
          </NavLink>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Balance"
          value={`$${parseFloat(stats?.totalBalance?.toString() || '0').toLocaleString()}`}
          change="+12.5%"
          changeType="positive"
          icon={Wallet}
          linkTo="/transactions"
        />
        <StatCard
          title="Total Invested"
          value={`$${parseFloat(stats?.totalInvested?.toString() || '0').toLocaleString()}`}
          icon={TrendingUp}
          linkTo="/investments"
        />
        <StatCard
          title="Total Profit"
          value={`$${parseFloat(stats?.totalProfit?.toString() || '0').toLocaleString()}`}
          change="+8.2%"
          changeType="positive"
          icon={DollarSign}
        />
        <StatCard
          title="Active Investments"
          value={`${stats?.activeInvestments || 0}`}
          icon={Clock}
          linkTo="/investments"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Chart */}
        <div className="lg:col-span-2 glass-card rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-white font-semibold flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#d4ff00]" />
              Portfolio Performance
            </h3>
            <div className="flex gap-2">
              {['1D', '1W', '1M', '1Y', 'All'].map((period) => (
                <button
                  key={period}
                  className={`px-3 py-1 rounded-lg text-sm transition-colors ${
                    period === '1M'
                      ? 'bg-[#d4ff00] text-black'
                      : 'bg-white/5 text-white/60 hover:text-white'
                  }`}
                >
                  {period}
                </button>
              ))}
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d4ff00" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#d4ff00" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  dataKey="date" 
                  stroke="rgba(255,255,255,0.4)"
                  fontSize={12}
                />
                <YAxis 
                  stroke="rgba(255,255,255,0.4)"
                  fontSize={12}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0a0a0a',
                    border: '1px solid rgba(212, 255, 0, 0.3)',
                    borderRadius: '8px',
                  }}
                  labelStyle={{ color: '#fff' }}
                  itemStyle={{ color: '#d4ff00' }}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#d4ff00"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorValue)"
                />
                <Area
                  type="monotone"
                  dataKey="profit"
                  stroke="#22c55e"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorProfit)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          <CryptoTicker />
          
          {/* Quick Actions */}
          <div className="glass-card p-4">
            <h3 className="text-white font-semibold mb-4">Quick Actions</h3>
            <div className="space-y-2">
              <NavLink 
                to="/investments" 
                className="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-[#d4ff00]/10 transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-5 h-5 text-[#d4ff00]" />
                  <span className="text-white">New Investment</span>
                </div>
                <ChevronRight className="w-4 h-4 text-white/40 group-hover:text-[#d4ff00]" />
              </NavLink>
              <NavLink 
                to="/deposit" 
                className="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-[#d4ff00]/10 transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <Bitcoin className="w-5 h-5 text-[#d4ff00]" />
                  <span className="text-white">Deposit BTC</span>
                </div>
                <ChevronRight className="w-4 h-4 text-white/40 group-hover:text-[#d4ff00]" />
              </NavLink>
              <NavLink 
                to="/settings" 
                className="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-[#d4ff00]/10 transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <Wallet className="w-5 h-5 text-[#d4ff00]" />
                  <span className="text-white">Wallet Settings</span>
                </div>
                <ChevronRight className="w-4 h-4 text-white/40 group-hover:text-[#d4ff00]" />
              </NavLink>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-white font-semibold flex items-center gap-2">
            <Clock className="w-5 h-5 text-[#d4ff00]" />
            Recent Transactions
          </h3>
          <NavLink to="/transactions" className="text-[#d4ff00] text-sm hover:underline">
            View All
          </NavLink>
        </div>
        <div className="divide-y divide-white/10">
          {transactions && transactions.length > 0 ? (
            transactions.map((transaction) => (
              <TransactionItem key={transaction.id} transaction={transaction} />
            ))
          ) : (
            <p className="text-white/40 text-center py-8">No transactions yet</p>
          )}
        </div>
      </div>
    </div>
  );
}
