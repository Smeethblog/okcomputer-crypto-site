import { create } from 'zustand';
import { adminAPI } from '@/services/api';

interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalInvestments: number;
  activeInvestments: number;
  totalDeposits: number;
  totalWithdrawals: number;
  pendingWithdrawals: number;
  pendingDeposits: number;
}

interface AdminState {
  stats: AdminStats | null;
  users: any[];
  pendingWithdrawals: any[];
  pendingDeposits: any[];
  investments: any[];
  btcPrice: { price: number; change24h: number } | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchStats: () => Promise<void>;
  fetchUsers: (params?: { search?: string; status?: string }) => Promise<void>;
  fetchPendingWithdrawals: () => Promise<void>;
  fetchPendingDeposits: () => Promise<void>;
  fetchInvestments: () => Promise<void>;
  fetchBTCPrice: () => Promise<void>;
  approveWithdrawal: (id: string) => Promise<void>;
  rejectWithdrawal: (id: string, reason?: string) => Promise<void>;
  confirmDeposit: (id: string) => Promise<void>;
  updateUserStatus: (id: string, status: string) => Promise<void>;
}

export const useAdminStore = create<AdminState>((set, get) => ({
  stats: null,
  users: [],
  pendingWithdrawals: [],
  pendingDeposits: [],
  investments: [],
  btcPrice: null,
  isLoading: false,
  error: null,

  fetchStats: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await adminAPI.getStats();
      set({ stats: response.stats, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchUsers: async (params?: { search?: string; status?: string }) => {
    set({ isLoading: true, error: null });
    try {
      const response = await adminAPI.getUsers(params);
      set({ users: response.users, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchPendingWithdrawals: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await adminAPI.getPendingWithdrawals();
      set({ pendingWithdrawals: response.withdrawals, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchPendingDeposits: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await adminAPI.getPendingDeposits();
      set({ pendingDeposits: response.deposits, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchInvestments: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await adminAPI.getInvestments();
      set({ investments: response.investments, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchBTCPrice: async () => {
    try {
      const response = await adminAPI.getBTCPrice();
      set({ btcPrice: response });
    } catch (error: any) {
      console.error('Fetch BTC price error:', error);
    }
  },

  approveWithdrawal: async (id: string) => {
    set({ isLoading: true, error: null });
    try {
      await adminAPI.approveWithdrawal(id);
      await get().fetchPendingWithdrawals();
      await get().fetchStats();
      set({ isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  rejectWithdrawal: async (id: string, reason?: string) => {
    set({ isLoading: true, error: null });
    try {
      await adminAPI.rejectWithdrawal(id, reason);
      await get().fetchPendingWithdrawals();
      await get().fetchStats();
      set({ isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  confirmDeposit: async (id: string) => {
    set({ isLoading: true, error: null });
    try {
      await adminAPI.confirmDeposit(id);
      await get().fetchPendingDeposits();
      await get().fetchStats();
      set({ isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  updateUserStatus: async (id: string, status: string) => {
    set({ isLoading: true, error: null });
    try {
      await adminAPI.updateUserStatus(id, status);
      await get().fetchUsers();
      set({ isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },
}));
