import { create } from 'zustand';
import { transactionAPI, withdrawalAPI, depositAPI } from '@/services/api';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  status: string;
  description: string;
  createdAt: string;
}

interface Withdrawal {
  id: string;
  amount: number;
  btcAmount: string;
  btcAddress: string;
  status: string;
  fee: number;
  createdAt: string;
}

interface Deposit {
  id: string;
  amount: number;
  btcAmount: string;
  btcAddress: string;
  status: string;
  confirmations: number;
  requiredConfirmations: number;
  createdAt: string;
}

interface TransactionState {
  transactions: Transaction[];
  withdrawals: Withdrawal[];
  deposits: Deposit[];
  summary: {
    deposits: number;
    withdrawals: number;
    investments: number;
    profits: number;
  } | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchTransactions: (params?: { type?: string; status?: string; limit?: number; offset?: number }) => Promise<void>;
  fetchSummary: () => Promise<void>;
  fetchWithdrawals: () => Promise<void>;
  fetchDeposits: () => Promise<void>;
  createWithdrawal: (amount: number, btcAddress: string) => Promise<Withdrawal | null>;
  createDeposit: (amount: number) => Promise<Deposit | null>;
  checkDepositStatus: (id: string) => Promise<void>;
}

export const useTransactionStore = create<TransactionState>((set, get) => ({
  transactions: [],
  withdrawals: [],
  deposits: [],
  summary: null,
  isLoading: false,
  error: null,

  fetchTransactions: async (params?: { type?: string; status?: string; limit?: number; offset?: number }) => {
    set({ isLoading: true, error: null });
    try {
      const response = await transactionAPI.getTransactions(params);
      set({ transactions: response.transactions, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchSummary: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await transactionAPI.getSummary();
      set({ summary: response.summary, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchWithdrawals: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await withdrawalAPI.getWithdrawals();
      set({ withdrawals: response.withdrawals, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchDeposits: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await depositAPI.getDeposits();
      set({ deposits: response.deposits, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  createWithdrawal: async (amount: number, btcAddress: string): Promise<Withdrawal | null> => {
    set({ isLoading: true, error: null });
    try {
      const response = await withdrawalAPI.createWithdrawal({ amount, btcAddress });
      await get().fetchWithdrawals();
      set({ isLoading: false });
      return response.withdrawal;
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  createDeposit: async (amount: number): Promise<Deposit | null> => {
    set({ isLoading: true, error: null });
    try {
      const response = await depositAPI.createDeposit({ amount });
      await get().fetchDeposits();
      set({ isLoading: false });
      return response.deposit;
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  checkDepositStatus: async (id: string) => {
    try {
      await depositAPI.checkStatus(id);
      await get().fetchDeposits();
    } catch (error: any) {
      console.error('Check deposit status error:', error);
    }
  },
}));
