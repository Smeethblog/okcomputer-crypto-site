import { create } from 'zustand';
import { investmentAPI } from '@/services/api';
import type { Investment, InvestmentPlan, DashboardStats } from '@/types';

interface InvestmentState {
  investments: Investment[];
  activeInvestments: Investment[];
  plans: InvestmentPlan[];
  stats: DashboardStats | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchInvestments: () => Promise<void>;
  fetchActiveInvestments: () => Promise<void>;
  fetchPlans: () => Promise<void>;
  fetchDashboardStats: () => Promise<void>;
  createInvestment: (planId: string, amount: number) => Promise<Investment | null>;
}

export const useInvestmentStore = create<InvestmentState>((set, get) => ({
  investments: [],
  activeInvestments: [],
  plans: [],
  stats: null,
  isLoading: false,
  error: null,

  fetchInvestments: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await investmentAPI.getInvestments();
      set({ investments: response.investments, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchActiveInvestments: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await investmentAPI.getActiveInvestments();
      set({ activeInvestments: response.investments, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchPlans: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await investmentAPI.getPlans();
      set({ plans: response.plans, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  fetchDashboardStats: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await investmentAPI.getDashboardStats();
      set({ stats: response.stats, isLoading: false });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  createInvestment: async (planId: string, amount: number): Promise<Investment | null> => {
    set({ isLoading: true, error: null });
    try {
      const response = await investmentAPI.createInvestment({ planId, amount });
      
      // Refresh data after creating investment
      await get().fetchInvestments();
      await get().fetchActiveInvestments();
      await get().fetchDashboardStats();
      
      set({ isLoading: false });
      return response.investment;
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },
}));
