import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authAPI } from '@/services/api';
import type { User, AuthState, RegisterData } from '@/types';

interface ExtendedAuthState extends AuthState {
  token: string | null;
  setToken: (token: string | null) => void;
  updateUser: (user: Partial<User>) => void;
  fetchUser: () => Promise<void>;
}

export const useAuthStore = create<ExtendedAuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,

      login: async (email: string, password: string): Promise<boolean> => {
        set({ isLoading: true });
        
        try {
          const response = await authAPI.login({ email, password });
          
          set({ 
            user: response.user, 
            token: response.token,
            isAuthenticated: true, 
            isLoading: false 
          });
          
          localStorage.setItem('token', response.token);
          return true;
        } catch (error: any) {
          set({ isLoading: false });
          throw new Error(error.message || 'Login failed');
        }
      },

      register: async (userData: RegisterData): Promise<boolean> => {
        set({ isLoading: true });
        
        try {
          const response = await authAPI.register(userData);
          
          set({ 
            user: response.user, 
            token: response.token,
            isAuthenticated: true,
            isLoading: false 
          });
          
          localStorage.setItem('token', response.token);
          return true;
        } catch (error: any) {
          set({ isLoading: false });
          throw new Error(error.message || 'Registration failed');
        }
      },

      logout: () => {
        localStorage.removeItem('token');
        set({ 
          user: null, 
          token: null,
          isAuthenticated: false,
        });
      },

      verifyEmail: async (_token: string): Promise<boolean> => {
        // Email verification is handled automatically in this implementation
        return true;
      },

      enable2FA: async (secret: string) => {
        const { user } = get();
        if (user) {
          set({ 
            user: { 
              ...user, 
              twoFactorEnabled: true, 
              twoFactorSecret: secret 
            } 
          });
        }
      },

      disable2FA: async () => {
        try {
          await authAPI.disable2FA();
          const { user } = get();
          if (user) {
            set({ 
              user: { 
                ...user, 
                twoFactorEnabled: false, 
                twoFactorSecret: undefined 
              } 
            });
          }
        } catch (error: any) {
          throw new Error(error.message || 'Failed to disable 2FA');
        }
      },

      setToken: (token: string | null) => {
        set({ token });
        if (token) {
          localStorage.setItem('token', token);
        } else {
          localStorage.removeItem('token');
        }
      },

      updateUser: (userData: Partial<User>) => {
        const { user } = get();
        if (user) {
          set({ user: { ...user, ...userData } });
        }
      },

      fetchUser: async () => {
        try {
          const response = await authAPI.getMe();
          set({ 
            user: response.user, 
            isAuthenticated: true 
          });
        } catch (error) {
          // Token is invalid, clear it
          localStorage.removeItem('token');
          set({ 
            user: null, 
            token: null,
            isAuthenticated: false 
          });
        }
      },
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ 
        user: state.user, 
        isAuthenticated: state.isAuthenticated,
        token: state.token,
      }),
    }
  )
);

// Initialize auth state from localStorage on app load
export const initializeAuth = async () => {
  const token = localStorage.getItem('token');
  if (token) {
    const { fetchUser } = useAuthStore.getState();
    await fetchUser();
  }
};
