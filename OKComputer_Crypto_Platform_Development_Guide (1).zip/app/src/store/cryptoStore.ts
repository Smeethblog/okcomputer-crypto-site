import { create } from 'zustand';
import type { CryptoPrice } from '@/types';

// Initial crypto prices
const initialPrices: CryptoPrice[] = [
  {
    symbol: 'BTC',
    name: 'Bitcoin',
    price: 96420.5,
    change24h: 2450.3,
    changePercent24h: 2.61,
    volume24h: 32500000000,
    marketCap: 1895000000000,
    high24h: 97800.0,
    low24h: 93800.2,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'ETH',
    name: 'Ethereum',
    price: 2850.75,
    change24h: 45.2,
    changePercent24h: 1.61,
    volume24h: 15200000000,
    marketCap: 342000000000,
    high24h: 2890.0,
    low24h: 2790.5,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'SOL',
    name: 'Solana',
    price: 198.45,
    change24h: 8.3,
    changePercent24h: 4.37,
    volume24h: 3200000000,
    marketCap: 92000000000,
    high24h: 202.1,
    low24h: 189.2,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'ADA',
    name: 'Cardano',
    price: 0.85,
    change24h: 0.03,
    changePercent24h: 3.66,
    volume24h: 450000000,
    marketCap: 30000000000,
    high24h: 0.87,
    low24h: 0.82,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'DOT',
    name: 'Polkadot',
    price: 7.25,
    change24h: 0.15,
    changePercent24h: 2.11,
    volume24h: 180000000,
    marketCap: 10500000000,
    high24h: 7.45,
    low24h: 7.05,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'LINK',
    name: 'Chainlink',
    price: 18.9,
    change24h: 0.45,
    changePercent24h: 2.44,
    volume24h: 320000000,
    marketCap: 11500000000,
    high24h: 19.2,
    low24h: 18.4,
    lastUpdated: new Date().toISOString(),
  },
];

interface CryptoState {
  prices: CryptoPrice[];
  isLoading: boolean;
  error: string | null;
  fetchPrices: () => Promise<void>;
  getPrice: (symbol: string) => CryptoPrice | undefined;
  startPriceUpdates: () => void;
  stopPriceUpdates: () => void;
}

let priceUpdateInterval: ReturnType<typeof setInterval> | null = null;

export const useCryptoStore = create<CryptoState>((set, get) => ({
  prices: initialPrices,
  isLoading: false,
  error: null,

  fetchPrices: async () => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call - in production, this would call a real crypto API
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Simulate price updates with small random changes
      const updatedPrices = get().prices.map(price => {
        const changePercent = (Math.random() - 0.5) * 0.5; // -0.25% to +0.25%
        const newPrice = price.price * (1 + changePercent / 100);
        const change24h = price.change24h + (Math.random() - 0.5) * 10;
        
        return {
          ...price,
          price: parseFloat(newPrice.toFixed(price.price < 1 ? 4 : 2)),
          change24h: parseFloat(change24h.toFixed(2)),
          changePercent24h: parseFloat(((change24h / (newPrice - change24h)) * 100).toFixed(2)),
          lastUpdated: new Date().toISOString(),
        };
      });
      
      set({ prices: updatedPrices, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch prices', isLoading: false });
    }
  },

  getPrice: (symbol: string) => {
    return get().prices.find(p => p.symbol === symbol.toUpperCase());
  },

  startPriceUpdates: () => {
    if (priceUpdateInterval) return;
    
    priceUpdateInterval = setInterval(() => {
      get().fetchPrices();
    }, 10000); // Update every 10 seconds
  },

  stopPriceUpdates: () => {
    if (priceUpdateInterval) {
      clearInterval(priceUpdateInterval);
      priceUpdateInterval = null;
    }
  },
}));
