const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Deposit = sequelize.define('Deposit', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'Users',
      key: 'id',
    },
  },
  amount: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  btcAmount: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  btcAddress: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('pending', 'confirming', 'completed', 'failed'),
    defaultValue: 'pending',
  },
  confirmations: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  requiredConfirmations: {
    type: DataTypes.INTEGER,
    defaultValue: 3,
  },
  txHash: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  completedAt: {
    type: DataTypes.DATE,
    allowNull: true,
  },
}, {
  tableName: 'Deposits',
});

module.exports = Deposit;
