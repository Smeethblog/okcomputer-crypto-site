const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Transaction = sequelize.define('Transaction', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'Users',
      key: 'id',
    },
  },
  type: {
    type: DataTypes.ENUM('deposit', 'withdrawal', 'investment', 'profit', 'referral', 'bonus'),
    allowNull: false,
  },
  amount: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('pending', 'completed', 'failed', 'cancelled'),
    defaultValue: 'pending',
  },
  description: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  txHash: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  btcAddress: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  btcAmount: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: true,
  },
  fee: {
    type: DataTypes.DECIMAL(20, 8),
    defaultValue: 0,
  },
  processedAt: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: true,
  },
}, {
  tableName: 'Transactions',
});

module.exports = Transaction;
