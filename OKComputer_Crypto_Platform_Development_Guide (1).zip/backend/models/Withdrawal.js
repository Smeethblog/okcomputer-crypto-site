const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Withdrawal = sequelize.define('Withdrawal', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'Users',
      key: 'id',
    },
  },
  amount: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  btcAmount: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  btcAddress: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('pending', 'processing', 'completed', 'failed', 'rejected'),
    defaultValue: 'pending',
  },
  fee: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  txHash: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  processedBy: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'Users',
      key: 'id',
    },
  },
  processedAt: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  rejectionReason: {
    type: DataTypes.STRING,
    allowNull: true,
  },
}, {
  tableName: 'Withdrawals',
});

module.exports = Withdrawal;
