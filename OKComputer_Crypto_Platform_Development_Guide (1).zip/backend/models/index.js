const sequelize = require('../config/database');
const User = require('./User');
const Investment = require('./Investment');
const Transaction = require('./Transaction');
const Deposit = require('./Deposit');
const Withdrawal = require('./Withdrawal');

// Define associations
User.hasMany(Investment, { foreignKey: 'userId', as: 'investments' });
Investment.belongsTo(User, { foreignKey: 'userId', as: 'user' });

User.hasMany(Transaction, { foreignKey: 'userId', as: 'transactions' });
Transaction.belongsTo(User, { foreignKey: 'userId', as: 'user' });

User.hasMany(Deposit, { foreignKey: 'userId', as: 'deposits' });
Deposit.belongsTo(User, { foreignKey: 'userId', as: 'user' });

User.hasMany(Withdrawal, { foreignKey: 'userId', as: 'withdrawals' });
Withdrawal.belongsTo(User, { foreignKey: 'userId', as: 'user' });

module.exports = {
  sequelize,
  User,
  Investment,
  Transaction,
  Deposit,
  Withdrawal,
};
