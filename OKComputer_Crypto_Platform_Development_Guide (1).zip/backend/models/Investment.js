const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Investment = sequelize.define('Investment', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'Users',
      key: 'id',
    },
  },
  planId: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  planName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  amount: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  dailyReturnPercent: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: false,
  },
  dailyReturn: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  totalReturn: {
    type: DataTypes.DECIMAL(20, 8),
    allowNull: false,
  },
  profit: {
    type: DataTypes.DECIMAL(20, 8),
    defaultValue: 0,
  },
  startDate: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  endDate: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('active', 'completed', 'cancelled'),
    defaultValue: 'active',
  },
  lastProfitCalculation: {
    type: DataTypes.DATE,
    allowNull: true,
  },
}, {
  tableName: 'Investments',
});

module.exports = Investment;
