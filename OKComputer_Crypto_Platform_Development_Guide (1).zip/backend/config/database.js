const { Sequelize } = require('sequelize');
require('dotenv').config();

// Use SQLite for development (no PostgreSQL setup needed)
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './database.sqlite',
  logging: false,
  define: {
    timestamps: true,
    underscored: true,
  },
});

// For production with PostgreSQL:
// const sequelize = new Sequelize(
//   process.env.DB_NAME,
//   process.env.DB_USER,
//   process.env.DB_PASSWORD,
//   {
//     host: process.env.DB_HOST,
//     port: process.env.DB_PORT,
//     dialect: 'postgres',
//     logging: false,
//   }
// );

module.exports = sequelize;
